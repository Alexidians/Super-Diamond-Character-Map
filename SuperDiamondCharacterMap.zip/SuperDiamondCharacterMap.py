def module_to_dict(module):
    """
    Convert a module's attributes into a dictionary using dir() and getattr().
    The keys of the dictionary will be the attribute names,
    and the values will be the attribute values of the module.

    Args:
    - module: The Python module to convert.

    Returns:
    - dict: A dictionary representing the module's attributes.
    """
    module_dict = {}
    for attribute_name in dir(module):
        try:
            # Get the attribute value using getattr
            attribute_value = getattr(module, attribute_name)
            # Store it in the dictionary
            module_dict[attribute_name] = attribute_value
        except Exception as e:
            # Handle any errors that may arise from attributes that cannot be accessed
            module_dict[attribute_name] = str(e)

    return module_dict

import json
import html
import emoji
import inspect
import os
#print(module_to_dict(emoji))
#print(emoji.EMOJI_DATA)
#print(inspect.getsource(emoji.emoji_list))
import sys
import json
from PyQt5.QtGui import QFont, QFontDatabase
from PyQt5.QtCore import Qt, QAbstractListModel
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QLineEdit, QListView, QPushButton, QMessageBox
import unicodedata
import string
import easygui
from fontTools.ttLib import TTFont
MAPPING_ENCODING = 'utf-8'

languages = [
    "all_charmaps",
    "english",
    "chinese",
    "japanese",
    "korean",
    "arabic",
    "hindi",
    "russian",
    "greek",
    "thai",
    "hebrew",
    "armenian",
    "bengali",
    "mongolian",
    "sinhala",
    "haitian_creole"
    # Add more languages here as needed
]

language_paths = {
    "all_charmaps": "chars/default/chars.json",
    "english": "chars/lang/english/english.json",
    "chinese": "chars/lang/chinese/chinese.json",
    "japanese": "chars/lang/japanese/japanese.json",
    "korean": "chars/lang/korean/korean.json",
    "arabic": "chars/lang/arabic/arabic.json",
    "hindi": "chars/lang/hindi/hindi.json",
    "russian": "chars/lang/russian/russian.json",
    "greek": "chars/lang/greek/greek.json",
    "thai": "chars/lang/thai/thai.json",
    "hebrew": "chars/lang/hebrew/hebrew.json",
    "armenian": "chars/lang/armenian/armenian.json",
    "bengali": "chars/lang/bengali/bengali.json",
    "mongolian": "chars/lang/mongolian/mongolian.json",
    "sinhala": "chars/lang/sinhala/sinhala.json",
    "haitian_creole": "chars/lang/haitian_creole/haitian_creole.json"
    # Add more paths here as needed
}


def ttf_to_qfont(ttf_path, font_size=12):
    """
    Converts a TrueType font file (.ttf) to a QFont object.

    Args:
    - ttf_path (str): Path to the .ttf font file.
    - font_size (int): The font size to apply (default is 12).

    Returns:
    - QFont: The QFont object created from the .ttf file.
    """
    # Load the font from the .ttf file
    font_id = QFontDatabase.addApplicationFont(ttf_path)
    
    # Get the font family name from the loaded font
    font_family = QFontDatabase.applicationFontFamilies(font_id)[0]
    
    # Create and return a QFont object using the loaded font family and the specified size
    return QFont(font_family, font_size)

def extract_characters_from_ttf(ttf_path):
    """
    Extract all characters from a TrueType font file (.ttf) and return them as an array of strings.

    :param ttf_path: The path to the .ttf font file.
    :return: A list of character strings in the font.
    """
    try:
        # Load the TTF font file
        font = TTFont(ttf_path)
        
        # Extract the 'cmap' table, which contains the character mappings
        cmap = font['cmap']
        
        # Get all encoding mappings in the 'cmap' table
        character_map = cmap.getBestCmap()
        
        # Extract the characters (glyphs) and convert their code points to string
        characters = [chr(code_point) for code_point in character_map.keys()]
        
        # Optionally, sort the characters if you want them in a specific order
        characters.sort()
        
        return characters

    except Exception as e:
        print(f"Error: {e}")
        return []

def generate_english_characters_json():
    # Create the directory if it doesn't exist
    os.makedirs("chars/lang/english", exist_ok=True)
    
    # Define the array of English characters (A-Z and a-z)
    english_characters = list(string.ascii_letters)  # Contains A-Z and a-z
    
    # Save the array to a JSON file
    with open("chars/lang/english/english.json", "w", encoding=MAPPING_ENCODING, errors="replace") as f:
        json.dump(english_characters, f, ensure_ascii=False, indent=4)
    
    print("English characters JSON file generated successfully!")

# Function to save charmap as JSON
def save_charmap(language, charmap, html_encode=False):
    os.makedirs(f'chars/lang/{language}/', exist_ok=True)
    # Apply HTML encoding if the flag is set
    if html_encode:
        charmap = [html.escape(char) for char in charmap]
    
    path = f'chars/lang/{language}/{language}.json'
    with open(path, 'w', encoding=MAPPING_ENCODING) as file:
        json.dump(charmap, file, ensure_ascii=False, indent=4)

# Function for Chinese (Simplified and Traditional)
def generate_chinese_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    chinese_chars = []
    for char_code in range(0x4E00, 0x9FFF + 1):  # Chinese characters block
        chinese_chars.append(chr(char_code))
    save_charmap('chinese', chinese_chars, html_encode)  # Pass html_encode value

# Function for Japanese
def generate_japanese_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    japanese_chars = []
    for char_code in range(0x3040, 0x30FF + 1):  # Hiragana and Katakana blocks
        japanese_chars.append(chr(char_code))
    save_charmap('japanese', japanese_chars, html_encode)  # Pass html_encode value

# Function for Korean
def generate_korean_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    korean_chars = []
    for char_code in range(0xAC00, 0xD7AF + 1):  # Hangul syllables block
        korean_chars.append(chr(char_code))
    save_charmap('korean', korean_chars, html_encode)  # Pass html_encode value

# Function for Arabic
def generate_arabic_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    arabic_chars = []
    for char_code in range(0x0600, 0x06FF + 1):  # Arabic block
        arabic_chars.append(chr(char_code))
    save_charmap('arabic', arabic_chars, html_encode)  # Pass html_encode value

# Function for Hindi
def generate_hindi_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    hindi_chars = []
    for char_code in range(0x0900, 0x097F + 1):  # Devanagari block for Hindi
        hindi_chars.append(chr(char_code))
    save_charmap('hindi', hindi_chars, html_encode)  # Pass html_encode value

# Function for Russian
def generate_russian_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    russian_chars = []
    for char_code in range(0x0400, 0x04FF + 1):  # Cyrillic block for Russian
        russian_chars.append(chr(char_code))
    save_charmap('russian', russian_chars, html_encode)  # Pass html_encode value

# Function for Greek
def generate_greek_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    greek_chars = []
    for char_code in range(0x0370, 0x03FF + 1):  # Greek block
        greek_chars.append(chr(char_code))
    save_charmap('greek', greek_chars, html_encode)  # Pass html_encode value

# Function for Thai
def generate_thai_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    thai_chars = []
    for char_code in range(0x0E00, 0x0E7F + 1):  # Thai block
        thai_chars.append(chr(char_code))
    save_charmap('thai', thai_chars, html_encode)  # Pass html_encode value

# Function for Hebrew
def generate_hebrew_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    hebrew_chars = []
    for char_code in range(0x0590, 0x05FF + 1):  # Hebrew block
        hebrew_chars.append(chr(char_code))
    save_charmap('hebrew', hebrew_chars, html_encode)  # Pass html_encode value

# Function for Armenian
def generate_armenian_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    armenian_chars = []
    for char_code in range(0x0530, 0x058F + 1):  # Armenian block
        armenian_chars.append(chr(char_code))
    save_charmap('armenian', armenian_chars, html_encode)  # Pass html_encode value

# Function for Bengali
def generate_bengali_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    bengali_chars = []
    for char_code in range(0x0980, 0x09FF + 1):  # Bengali block
        bengali_chars.append(chr(char_code))
    save_charmap('bengali', bengali_chars, html_encode)  # Pass html_encode value

# Function for Mongolian
def generate_mongolian_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    mongolian_chars = []
    for char_code in range(0x1800, 0x18AF + 1):  # Mongolian block
        mongolian_chars.append(chr(char_code))
    save_charmap('mongolian', mongolian_chars, html_encode)  # Pass html_encode value

# Function for Sinhala
def generate_sinhala_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    sinhala_chars = []
    for char_code in range(0x0D80, 0x0DFF + 1):  # Sinhala block
        sinhala_chars.append(chr(char_code))
    save_charmap('sinhala', sinhala_chars, html_encode)  # Pass html_encode value

# Function for Haitian Creole (Latin script)
def generate_haïtian_creole_charmap():
    html_encode = '--html-encode' in sys.argv  # Check for html encoding flag in sys.argv
    haitian_creole_chars = []
    for char_code in range(0x0020, 0x007F + 1):  # Latin script block for Haitian Creole
        haitian_creole_chars.append(chr(char_code))
    save_charmap('haitian_creole', haitian_creole_chars, html_encode)  # Pass html_encode value

def generate_all_charmaps():
    for language_gen in language_generators:
        # Skip the "all_charmaps" entry to prevent recursion
        if language_gen == "all_charmaps":
            continue
        
        # Call the language generator function
        language_generators[language_gen]()
    
    # Call additional functions after generating the language charmaps
    generate_emojis()
    generate_chars()
    generate_chars_printable()


    
language_generators = {
    "all_charmaps": generate_all_charmaps,
    "english": generate_english_characters_json,
    "chinese": generate_chinese_charmap,
    "japanese": generate_japanese_charmap,
    "korean": generate_korean_charmap,
    "arabic": generate_arabic_charmap,
    "hindi": generate_hindi_charmap,
    "russian": generate_russian_charmap,
    "greek": generate_greek_charmap,
    "thai": generate_thai_charmap,
    "hebrew": generate_hebrew_charmap,
    "armenian": generate_armenian_charmap,
    "bengali": generate_bengali_charmap,
    "mongolian": generate_mongolian_charmap,
    "sinhala": generate_sinhala_charmap,
    "haitian_creole": generate_haïtian_creole_charmap,
    # Add more languages below as needed
}


def load_language(path):
    if not os.path.exists(path):
        raise Exception('The language has not been generated as a character map. generate it and try again.')
    with open(path, 'r', encoding=MAPPING_ENCODING) as f:
        return json.load(f)

def select_language():
    return easygui.choicebox("Select an language:", "Language Selection", languages)

def generate_language_chars():
    language = select_language()
    language_generators[language]()

def load_language_chars():
    language = select_language()
    return load_language(language_paths[language])

def is_writable(char, encoding=MAPPING_ENCODING):
    #try:
    #    with open('writabletest.char', 'w', encoding=encoding) as f:
    #        f.write(char)
    #    return True
    #except Exception as e:
    #    return False
    return True


# -------------------------------
# Generate HTML Special Characters JSON (Array format with only strings)
# -------------------------------
def generate_chars_printable():
    html_special_chars = []
    os.makedirs("chars/general/", exist_ok=True)

    # Range of characters (Basic Multilingual Plane: U+0000 to U+FFFF)
    for i in range(0, 65536):  # Basic Multilingual Plane (BMP)
        char = chr(i)
        if char.isprintable():  # Filter to include only printable characters
            if not is_writable(char):
                pass
            if "--html-encode" in sys.argv:
                char = html.encode(char)
            html_special_chars.append(char)

    # Save HTML special characters to JSON file
    with open('chars/general/chars_printable.json', 'w', encoding=MAPPING_ENCODING, errors='replace') as f:
        json.dump(html_special_chars, f, ensure_ascii=False, indent=4)
    
# -------------------------------
# Generate HTML Special Characters JSON (Array format with only strings)
# -------------------------------
def generate_chars():
    html_special_chars = []
    os.makedirs("chars/general/", exist_ok=True)

    # Range of characters (Basic Multilingual Plane: U+0000 to U+FFFF)
    for i in range(0, 65536):  # Basic Multilingual Plane (BMP)
        char = chr(i)
        if not is_writable(char):
             pass
        if "--html-encode" in sys.argv:
            char = html.encode(char)
        html_special_chars.append(char)

    # Save HTML special characters to JSON file
    with open('chars/general/chars.json', 'w', encoding=MAPPING_ENCODING, errors='replace') as f:
        json.dump(html_special_chars, f, ensure_ascii=False, indent=4)
    
# -------------------------------
# Generate Emojis JSON (Array format with only strings)
# -------------------------------

def generate_emojis():
    os.makedirs("chars/emojis", exist_ok=True)
    # Get all emojis from the emoji.EMOJI_DATA
    emojis = list(emoji.EMOJI_DATA.keys())
    
    # Check if the '--html-encode' flag is in the command-line arguments
    if "--html-encode" in sys.argv:
        # HTML encode all emojis
        emojis = [html.escape(e) for e in emojis]
    
    with open('chars/emojis/emojis.json', 'w', encoding=MAPPING_ENCODING, errors='replace') as f:
        json.dump(emojis, f, ensure_ascii=False, indent=4)

def generate_emojis_old():
    import emoji
    emoji_list = []

    # Iterate over all emojis in the emoji module
    for e in emoji.EMOJI_UNICODE_ENGLISH:
        if not is_writable(e):
             pass
        if "--html-encode" in sys.argv:
            e = html.encode(e)
        emoji_list.append(e)

    # Save emojis to JSON file
    with open('chars/emojis/emojis.json', 'w', encoding=MAPPING_ENCODING, errors='replace') as f:
        json.dump(emoji_list, f, ensure_ascii=False, indent=4)
    
    
# -------------------------------
# Load the JSON files
# -------------------------------
def load_chars():
    if not os.path.exists('chars.json'):
        generate_chars()
    with open('chars/general/chars.json', 'r', encoding=MAPPING_ENCODING) as f:
        return json.load(f)
        
def load_chars_printable():
    if not os.path.exists('chars_printable.json'):
        generate_chars_printable()
    with open('chars/general/chars_printable.json', 'r', encoding=MAPPING_ENCODING) as f:
        return json.load(f)
        
def load_emojis():
    if not os.path.exists('emojis.json'):
        generate_emojis()
    with open('chars/emojis/emojis.json', 'r', encoding=MAPPING_ENCODING) as f:
        return json.load(f)
# -------------------------------
# List Model for HTML Special Chars and Emojis
# -------------------------------
class SearchableListModel(QAbstractListModel):
    def __init__(self, data=None):
        super().__init__()
        self.set_data(data)

    def set_data(self, data):
        self.data_list = data
        self.filtered_data = data
        self.layoutChanged.emit()

    def rowCount(self, parent=None):
        return len(self.filtered_data)

    def data(self, index, role):
        if role == Qt.DisplayRole:
            return self.filtered_data[index.row()]

    def filter_data(self, filter_text):
        self.filtered_data = [item for item in self.data_list if filter_text.lower() in item.lower()]
        self.layoutChanged.emit()

# -------------------------------
# Main Window
# -------------------------------
class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle('Searchable Special Characters & Emojis')
        self.setGeometry(100, 100, 600, 400)

        # Layout and widget setup
        self.layout = QVBoxLayout()

        self.search_bar = QLineEdit(self)
        self.search_bar.setPlaceholderText("Search...")
        self.search_bar.textChanged.connect(self.on_search)

        # Create QListView in Icon mode
        self.list_view = QListView(self)
        self.list_view.setViewMode(QListView.IconMode)
        self.list_view.setSpacing(10)  # Adjust spacing between items
        self.list_view.setFlow(QListView.LeftToRight)  # Wrap items horizontally
        # Connect the clicked signal to a slot (function) to handle clicks
        self.list_view.clicked.connect(self.on_item_clicked)

        self.export_charmap_button = QPushButton("Export Charmap", self)
        self.export_charmap_button.clicked.connect(self.export_charmap)

        self.import_charmap_button = QPushButton("Import Charmap", self)
        self.import_charmap_button.clicked.connect(self.import_charmap)


        # Buttons to load JSON data
        self.load_char_button = QPushButton("Load Chars", self)
        self.load_char_button.clicked.connect(self.load_char_data)

        # Buttons to load JSON data
        self.load_char_printable_button = QPushButton("Load Chars Printable", self)
        self.load_char_printable_button.clicked.connect(self.load_char_printable_data)

        self.load_emoji_button = QPushButton("Load Emojis", self)
        self.load_emoji_button.clicked.connect(self.load_emoji_data)
        
        self.load_language_button = QPushButton("Load Language Chars", self)
        self.load_language_button.clicked.connect(self.load_language_chars_data)
        
        self.load_font_button = QPushButton("Load Font", self)
        self.load_font_button.clicked.connect(self.load_font_data)
        
        # Buttons to load JSON data
        self.generate_char_button = QPushButton("Generate Chars", self)
        self.generate_char_button.clicked.connect(generate_chars)

        self.generate_char_printable_button = QPushButton("Generate Chars Printable", self)
        self.generate_char_printable_button.clicked.connect(generate_chars_printable)

        self.generate_emoji_button = QPushButton("Generate Emojis", self)
        self.generate_emoji_button.clicked.connect(generate_emojis)

        self.generate_language_button = QPushButton("Generate Language Chars", self)
        self.generate_language_button.clicked.connect(generate_language_chars)

        # Add widgets to layout
        self.layout.addWidget(self.search_bar)
        self.layout.addWidget(self.load_char_button)
        self.layout.addWidget(self.load_char_printable_button)
        self.layout.addWidget(self.load_emoji_button)
        self.layout.addWidget(self.load_language_button)
        self.layout.addWidget(self.load_font_button)
        self.layout.addWidget(self.generate_char_button)
        self.layout.addWidget(self.generate_char_printable_button)
        self.layout.addWidget(self.generate_emoji_button)
        self.layout.addWidget(self.generate_language_button)
        self.layout.addWidget(self.list_view)
        self.layout.addWidget(self.export_charmap_button)
        self.layout.addWidget(self.import_charmap_button)

        # Set the main widget
        container = QWidget()
        container.setLayout(self.layout)
        self.setCentralWidget(container)

        # Initialize the model with empty data
        self.model = SearchableListModel([])
        self.list_view.setModel(self.model)

    def on_item_clicked(self, index):
        # Get the clicked item's data
        item = self.model.data(index, Qt.DisplayRole)
        
        # Copy the emoji to the clipboard
        clipboard = QApplication.clipboard()
        clipboard.setText(item)
        
    def load_language_chars_data(self):
        try:
            self.all_items = load_language_chars()
            self.model.set_data(self.all_items)
        except Exception as e:
            self.show_message("Error", f"Failed to load Language Characters: {str(e)}")

    def on_search(self):
        # Filter the list based on the text entered in the search bar
        filter_text = self.search_bar.text()
        self.model.filter_data(filter_text)

    def export_charmap(self):
        try:
            charmap_path = easygui.filesavebox(title="Save charmap as .json")
            with open(charmap_path, 'w', encoding=MAPPING_ENCODING, errors='replace') as f:
                json.dump(self.all_items, f, ensure_ascii=False, indent=4)
        except Exception as e:
            self.show_message("Error", f"Failed to All characters: {str(e)}")

    def import_charmap(self):
        try:
            charmap_path = easygui.fileopenbox(title="Select an .json charmap for this app.")

            with open(charmap_path, 'r', encoding=MAPPING_ENCODING) as file:
                self.all_items = json.load(file)

        except Exception as e:
            self.show_message("Error", f"Failed to All characters: {str(e)}")

    def load_font_data(self):
        try:
            ttf_path = easygui.fileopenbox(title="Select .ttf font file")
            self.all_items = extract_characters_from_ttf(ttf_path)
            self.model.set_data(self.all_items)
            self.list_view.setFont(ttf_to_qfont(ttf_path, 14))
        except Exception as e:
            self.show_message("Error", f"Failed to All characters: {str(e)}")

    def load_char_printable_data(self):
        try:
            self.all_items = load_chars_printable()
            self.model.set_data(self.all_items)
            self.list_view.setFont(QFont())
        except Exception as e:
            self.show_message("Error", f"Failed to load All Printable characters: {str(e)}")

    def load_char_data(self):
        try:
            self.all_items = load_chars()
            self.model.set_data(self.all_items)
            self.list_view.setFont(QFont())
        except Exception as e:
            self.show_message("Error", f"Failed to load All Printable characters: {str(e)}")

    def load_emoji_data(self):
        try:
            self.all_items = load_emojis()
            self.model.set_data(self.all_items)
            self.list_view.setFont(QFont())
        except Exception as e:
            self.show_message("Error", f"Failed to load emojis: {str(e)}")

    def show_message(self, title, message):
        msg_box = QMessageBox()
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.exec_()

# -------------------------------
# Run the application
# -------------------------------
def run_app():
    app = QApplication(sys.argv)
    window = MainWindow()
    window.show()
    sys.exit(app.exec_())

if __name__ == '__main__':
    run_app()
